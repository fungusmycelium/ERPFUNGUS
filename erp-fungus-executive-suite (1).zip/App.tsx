
import React, { useState, useEffect } from 'react';
import { View, UserRole } from './types';
import Dashboard from './views/Dashboard';
import SalesOrder from './views/SalesOrder';
import PurchaseRegistry from './views/PurchaseRegistry';
import Analysis from './views/Analysis';
import CRM from './views/CRM';
import SalesList from './views/SalesList';
import PurchasesList from './views/PurchasesList';
import Inventory from './views/Inventory';
import ProductCatalog from './views/ProductCatalog';
import Finance from './views/Finance';
import Sidebar from './components/Sidebar';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>(View.DASHBOARD);
  const [userRole, setUserRole] = useState<UserRole>(() => {
    return (localStorage.getItem('fungus_user_role') as UserRole) || 'ADMIN';
  });

  useEffect(() => {
    localStorage.setItem('fungus_user_role', userRole);
  }, [userRole]);

  const renderView = () => {
    switch (currentView) {
      case View.DASHBOARD:
        return <Dashboard onNewSale={() => setCurrentView(View.SALES_ORDER)} />;
      case View.SALES_LIST:
        return <SalesList onNew={() => setCurrentView(View.SALES_ORDER)} />;
      case View.PURCHASES_LIST:
        return <PurchasesList onNew={() => setCurrentView(View.PURCHASE_REGISTRY)} />;
      case View.INVENTORY:
        return <Inventory />;
      case View.PRODUCT_CATALOG:
        return <ProductCatalog />;
      case View.CRM:
        return <CRM />;
      case View.FINANCE:
        return <Finance />;
      case View.SALES_ORDER:
        return <SalesOrder onBack={() => setCurrentView(View.SALES_LIST)} />;
      case View.PURCHASE_REGISTRY:
        return <PurchaseRegistry onBack={() => setCurrentView(View.PURCHASES_LIST)} />;
      case View.ANALYSIS:
        return <Analysis />;
      default:
        return <Dashboard onNewSale={() => setCurrentView(View.SALES_ORDER)} />;
    }
  };

  const isFullscreenView = [View.SALES_ORDER, View.PURCHASE_REGISTRY].includes(currentView);

  return (
    <div className="flex h-screen w-full bg-background-dark text-slate-100 overflow-hidden font-display">
      {!isFullscreenView && (
        <Sidebar 
          activeView={currentView} 
          setView={setCurrentView} 
          role={userRole} 
          setRole={setUserRole}
        />
      )}
      
      <main className={`flex-1 overflow-y-auto bg-background-dark ${isFullscreenView ? '' : 'p-2'}`}>
        <div className={`h-full ${isFullscreenView ? '' : 'rounded-3xl border border-surface-accent bg-surface-dark/30 shadow-inner'}`}>
          {renderView()}
        </div>
      </main>
    </div>
  );
};

export default App;
